#version 330 core

in vec2 texCoord;
in vec3 CubeNormal;
in vec3 FragPos;

out vec4 ObjColor;

uniform sampler2D myTex;

uniform vec3 vPos;
uniform vec3 lightPosition;
uniform vec3 solidColor;

//spot light
uniform vec3 spotDir;
uniform float cutOff;

uniform int count;

void main()
{
     vec3 lightPos = vec3(150.0f, 100.0f, -100.0f);
     vec3 lightColor = vec3(1.0f, 1.0f, 1.0f);
	vec3 objectColor = vec3(1.0f, 1.0f, 1.0f);
     vec3 lightDir = normalize(lightPos - FragPos);

	vec3 objectColor = vec3(solidColor.rgb);
     vec3 lightDir = normalize(lightPosition - FragPos);
     float theta = dot(lightDir, normalize(-spotDir));
     
     //ambient
     float ambientStrength = 0.3f;
     vec3 ambient = ambientStrength * lightColor;

     //diffuse
     vec3 norm = normalize(ObjNormal);
     float diff = max(dot(norm, lightDir), 0.0f);
     vec3 diffuse = diff * lightColor;

     //specular
     float specularStrength = 0.1f;
     vec3 viewDir = normalize(vPos - FragPos);
     vec3 reflectDir = reflect(-lightDir, norm);
     float spec = pow(max(dot(viewDir, reflectDir), 0.0f), 128);
     vec3 specular = specularStrength * spec * lightColor;
     
     vec3 result = (ambient + diffuse + specular) * objectColor;
     ObjColor = vec4(result, 1.0f);
}