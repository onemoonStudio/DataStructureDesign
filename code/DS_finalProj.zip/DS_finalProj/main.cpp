#define STB_IMAGE_IMPLEMENTATION

#include "Application.h"
#include "DS.h"

Application *app;

void KeyCallback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	app->KeyInput(key, action, mods);

}

void MouseCallback(GLFWwindow* window, double xpos, double ypos)
{
	app->MouseInput(xpos, ypos);
}

void MouseClickCallback(GLFWwindow* window, int button, int action, int mods)
{

}

void reSizeCallback(GLFWwindow* window, int w, int h)
{
	glViewport(0, 0, w, h);

}

int main()
{
	glfwInit();

	app = new DS();

	GLFWwindow *window = glfwCreateWindow(1600, 900, "pshEngine_vs2013", NULL, NULL);
	if (window == NULL)
	{
		cout << "Failed to create GLFW window" << endl;
		app->ReleaseApp();
		glfwTerminate();
		return -1;
	}

	glfwMakeContextCurrent(window);
	glfwSetKeyCallback(window, KeyCallback);
	glfwSetCursorPosCallback(window, MouseCallback);
	glfwSetMouseButtonCallback(window, MouseClickCallback);
	glfwSetWindowSizeCallback(window, reSizeCallback);

	glewExperimental = GL_TRUE;

	GLenum err = glewInit();

	if (GLEW_OK != err)
	{
		cout << " Load Fail : GLEW Library" << endl;
		cerr << glewGetErrorString(err) << endl;

	}
	else
		cout << " Ready for GLEW Library " << endl;

	app->InitApp();

	glEnable(GL_DEPTH_TEST);

	while (!glfwWindowShouldClose(window))
	{
		glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		app->RenderApp();

		glfwSwapBuffers(window);
		glfwPollEvents();

	}

	app->ReleaseApp();

	glfwTerminate();

	return 0;
}
