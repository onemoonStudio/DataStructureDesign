#version 330 core

in vec2 texCoord;
in vec3 CubeNormal;
in vec3 FragPos;

out vec4 ObjColor;

uniform sampler2D myTex;
void main()
{
     vec4 texColor = texture2D(myTex, texCoord);
	vec3 objectColor = vec3(texColor.rgb);

     ObjColor = vec4(objectColor, 1.0f);
     
}