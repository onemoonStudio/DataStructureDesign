#include "DSCamera.h"


DSCamera::DSCamera()
{
}


DSCamera::~DSCamera()
{
}

void DSCamera::InitCamera(vector<pair<float,float>> move_point__,vector<int> floor__)
{
	cameraPos = glm::vec3(28.0f, 40.0f, 40.0f);
	cameraFront = glm::vec3(0.0f, -1.0f, -0.6f);
	cameraUp = glm::vec3(0.0f, 0.0f, -1.0f);

	mModelMat = glm::mat4(1);
	mViewMat = glm::lookAt(cameraPos, cameraFront, cameraUp);
	mProjMat = glm::perspective(45.0f, (float)1600 / (float)900, 0.1f, 1000.0f);

	for (int i = 0; i < floor__.size(); i++) {
		floor_all.push_back(floor__[i]);
	}
	//���� ����
	//move_point_pair = algo.my_result();
	int loc = 0;
	floor = floor__[loc] - 1;

	for (vector<int>::size_type i = 0; i < move_point__.size(); i++) {
		if (move_point__[i].first == -1000 && move_point__[i].second == -1000) {
			loc++;
			floor = floor__[loc] - 1;
		}
		else {
			cout << move_point__[i].first << " " << move_point__[i].second << endl;
			move_point.push_back(std::make_tuple(move_point__[i].first, move_point__[i].second, floor * 100));
		}
	}

	move_time_end = move_point.size() - 1;
	move_time = 0;

	for (vector<int>::size_type i = 0; i < move_point.size()-1; i++) {
		startPointArr[i].x = get<0>(move_point[i]) * 0.2f;
		startPointArr[i].y = get<2>(move_point[i]) + 1.6f - 0.01f;
		startPointArr[i].z = get<1>(move_point[i]) * 0.2f;

		lastPointArr[i].x = get<0>(move_point[i + 1]) * 0.2f;
		lastPointArr[i].y = get<2>(move_point[i + 1]) + 1.6f - 0.01f;
		lastPointArr[i].z = get<1>(move_point[i + 1]) * 0.2f;

		movePointArr[i] = startPointArr[i];

		lineArr[i].InitBuffers("Line.vs", "Line.fs", startPointArr[i], movePointArr[i]);
	}
	
	//�� ���
	pointerModel = glm::translate(pointerModel, glm::vec3(0.0f, 0.2f, 0.0f));
	pointer.InitBuffers("Pointer.vs", "Pointer.fs", startPointArr[0]);


	//1�� ����
	firstFloorModel = glm::translate(firstFloorModel, glm::vec3(0.0f, 0.0f, 0.0f));
	firstFloorModel = glm::scale(firstFloorModel, glm::vec3(0.2f));
	firstFloor.loadModel("1f.obj", "floor1.vs", "floor1.fs", "floor.tga");

	//2�� ����
	secondFloorModel = glm::translate(secondFloorModel, glm::vec3(0.0f, 100.0f, 0.0f));
	secondFloorModel = glm::scale(secondFloorModel, glm::vec3(0.2f));
	secondFloor.loadModel("2f.obj", "floor2.vs", "floor2.fs", "floor.tga");

	//3�� ����
	thirdFloorModel = glm::translate(thirdFloorModel, glm::vec3(0.0f, 200.0f, 0.0f));
	thirdFloorModel = glm::scale(thirdFloorModel, glm::vec3(0.2f));
	thirdFloor.loadModel("3f.obj", "floor3.vs", "floor3.fs", "floor.tga");

	//4�� ����
	fourthFloorModel = glm::translate(fourthFloorModel, glm::vec3(0.0f, 300.0f, 0.0f));
	fourthFloorModel = glm::scale(fourthFloorModel, glm::vec3(0.2f));
	fourthFloor.loadModel("4f.obj", "floor4.vs", "floor4.fs", "floor.tga");

	//5�� ����
	fifthFloorModel = glm::translate(fifthFloorModel, glm::vec3(0.0f,400.0f, 0.0f));
	fifthFloorModel = glm::scale(fifthFloorModel, glm::vec3(0.2f));
	fifthFloor.loadModel("5f.obj", "floor5.vs", "floor5.fs", "floor.tga");
	
	//6�� ����
	sixthFloorModel = glm::translate(sixthFloorModel, glm::vec3(0.0f, 500.0f, 0.0f));
	sixthFloorModel = glm::scale(sixthFloorModel, glm::vec3(0.2f));
	sixthFloor.loadModel("6f.obj", "floor6.vs", "floor6.fs", "floor.tga");
	
	//7�� ����
	seventhFloorModel = glm::translate(seventhFloorModel, glm::vec3(0.0f, 600.0f, 0.0f));
	seventhFloorModel = glm::scale(seventhFloorModel, glm::vec3(0.2f));
	seventhFloor.loadModel("7f.obj", "floor7.vs", "floor7.fs", "floor.tga");
	
	//8�� ����
	eighthFloorModel = glm::translate(eighthFloorModel, glm::vec3(0.0f, 700.0f, 0.0f));
	eighthFloorModel = glm::scale(eighthFloorModel, glm::vec3(0.2f));
	eighthFloor.loadModel("8f.obj", "floor8.vs", "floor8.fs", "floor.tga");

	//9�� ����
	ninthFloorModel = glm::translate(ninthFloorModel, glm::vec3(0.0f, 800.0f, 0.0f));
	ninthFloorModel = glm::scale(ninthFloorModel, glm::vec3(0.2f));
	ninthFloor.loadModel("9f.obj", "floor9.vs", "floor9.fs", "floor.tga");
	

	//���� ����
	EVCube1Model[0] = glm::translate(EVCube1Model[0], glm::vec3(195.0f / 5.0f, 1.6f, 113.0f / 5.0f));
	EVCube1Model[0] = glm::scale(EVCube1Model[0], glm::vec3(1.0f, 0.01f, 1.0f));
	EVCube1Model[1] = glm::translate(EVCube1Model[1], glm::vec3(114.0f / 5.0f, 1.6f, 128.0f / 5.0f));
	EVCube1Model[1] = glm::scale(EVCube1Model[1], glm::vec3(1.4f, 0.01f, 1.4f));
	EVCube1Model[2] = glm::translate(EVCube1Model[2], glm::vec3(170.0f / 5.0f, 1.6f, 168.0f / 5.0f));
	EVCube1Model[2] = glm::scale(EVCube1Model[2], glm::vec3(1.0f, 0.01f, 1.0f));

	EVCube2Model[0] = glm::translate(EVCube2Model[0], glm::vec3(195.0f / 5.0f, 101.6f, 113.0f / 5.0f));
	EVCube2Model[0] = glm::scale(EVCube2Model[0], glm::vec3(1.0f, 0.01f, 1.0f));
	EVCube2Model[1] = glm::translate(EVCube2Model[1], glm::vec3(114.0f / 5.0f, 101.6f, 128.0f / 5.0f));
	EVCube2Model[1] = glm::scale(EVCube2Model[1], glm::vec3(1.0f, 0.01f, 1.0f));
	EVCube2Model[2] = glm::translate(EVCube2Model[2], glm::vec3(170.0f / 5.0f, 101.6f, 168.0f / 5.0f));
	EVCube2Model[2] = glm::scale(EVCube2Model[2], glm::vec3(1.0f, 0.01f, 1.0f));

	EVCube3Model[0] = glm::translate(EVCube3Model[0], glm::vec3(111.0f / 5.0f, 201.6f, 81.5f / 5.0f));
	EVCube3Model[0] = glm::scale(EVCube3Model[0], glm::vec3(1.0f, 0.01f, 1.0f));
	EVCube3Model[1] = glm::translate(EVCube3Model[1], glm::vec3(195.0f / 5.0f, 201.6f, 67.0f / 5.0f));
	EVCube3Model[1] = glm::scale(EVCube3Model[1], glm::vec3(1.0f, 0.01f, 1.0f));
	EVCube3Model[2] = glm::translate(EVCube3Model[2], glm::vec3(167.0f / 5.0f, 201.6f, 124.0f / 5.0f));
	EVCube3Model[2] = glm::scale(EVCube3Model[2], glm::vec3(1.0f, 0.01f, 1.0f));

	EVCube4Model[0] = glm::translate(EVCube4Model[0], glm::vec3(111.0f / 5.0f, 301.6f, 81.5f / 5.0f));
	EVCube4Model[0] = glm::scale(EVCube4Model[0], glm::vec3(1.0f, 0.01f, 1.0f));
	EVCube4Model[1] = glm::translate(EVCube4Model[1], glm::vec3(195.0f / 5.0f, 301.6f, 67.0f / 5.0f));
	EVCube4Model[1] = glm::scale(EVCube4Model[1], glm::vec3(1.0f, 0.01f, 1.0f));
	EVCube4Model[2] = glm::translate(EVCube4Model[2], glm::vec3(167.0f / 5.0f, 301.6f, 124.0f / 5.0f));
	EVCube4Model[2] = glm::scale(EVCube4Model[2], glm::vec3(1.0f, 0.01f, 1.0f));

	EVCube5Model[0] = glm::translate(EVCube5Model[0], glm::vec3(111.0f / 5.0f, 401.6f, 81.5f / 5.0f));
	EVCube5Model[0] = glm::scale(EVCube5Model[0], glm::vec3(1.0f, 0.01f, 1.0f));
	EVCube5Model[1] = glm::translate(EVCube5Model[1], glm::vec3(195.0f / 5.0f, 401.6f, 67.0f / 5.0f));
	EVCube5Model[1] = glm::scale(EVCube5Model[1], glm::vec3(1.0f, 0.01f, 1.0f));
	EVCube5Model[2] = glm::translate(EVCube5Model[2], glm::vec3(167.0f / 5.0f, 401.6f, 124.0f / 5.0f));
	EVCube5Model[2] = glm::scale(EVCube5Model[2], glm::vec3(1.0f, 0.01f, 1.0f));

	EVCube6Model[0] = glm::translate(EVCube6Model[0], glm::vec3(111.0f / 5.0f, 501.6f, 81.5f / 5.0f));
	EVCube6Model[0] = glm::scale(EVCube6Model[0], glm::vec3(1.0f, 0.01f, 1.0f));
	EVCube6Model[1] = glm::translate(EVCube6Model[1], glm::vec3(195.0f / 5.0f, 501.6f, 67.0f / 5.0f));
	EVCube6Model[1] = glm::scale(EVCube6Model[1], glm::vec3(1.0f, 0.01f, 1.0f));
	EVCube6Model[2] = glm::translate(EVCube6Model[2], glm::vec3(167.0f / 5.0f, 501.6f, 124.0f / 5.0f));
	EVCube6Model[2] = glm::scale(EVCube6Model[2], glm::vec3(1.0f, 0.01f, 1.0f));

	EVCube7Model[0] = glm::translate(EVCube7Model[0], glm::vec3(111.0f / 5.0f, 601.6f, 81.5f / 5.0f));
	EVCube7Model[0] = glm::scale(EVCube7Model[0], glm::vec3(1.0f, 0.01f, 1.0f));
	EVCube7Model[1] = glm::translate(EVCube7Model[1], glm::vec3(195.0f / 5.0f, 601.6f, 67.0f / 5.0f));
	EVCube7Model[1] = glm::scale(EVCube7Model[1], glm::vec3(1.0f, 0.01f, 1.0f));
	EVCube7Model[2] = glm::translate(EVCube7Model[2], glm::vec3(167.0f / 5.0f, 601.6f, 124.0f / 5.0f));
	EVCube7Model[2] = glm::scale(EVCube7Model[2], glm::vec3(1.0f, 0.01f, 1.0f));

	EVCube8Model[0] = glm::translate(EVCube8Model[0], glm::vec3(111.0f / 5.0f, 701.6f, 81.5f / 5.0f));
	EVCube8Model[0] = glm::scale(EVCube8Model[0], glm::vec3(1.0f, 0.01f, 1.0f));
	EVCube8Model[1] = glm::translate(EVCube8Model[1], glm::vec3(195.0f / 5.0f, 701.6f, 67.0f / 5.0f));
	EVCube8Model[1] = glm::scale(EVCube8Model[1], glm::vec3(1.0f, 0.01f, 1.0f));
	EVCube8Model[2] = glm::translate(EVCube8Model[2], glm::vec3(167.0f / 5.0f, 701.6f, 124.0f / 5.0f));
	EVCube8Model[2] = glm::scale(EVCube8Model[2], glm::vec3(1.0f, 0.01f, 1.0f));

	EVCube9Model[0] = glm::translate(EVCube9Model[0], glm::vec3(111.0f / 5.0f, 801.6f, 81.5f / 5.0f));
	EVCube9Model[0] = glm::scale(EVCube9Model[0], glm::vec3(1.0f, 0.01f, 1.0f));
	EVCube9Model[1] = glm::translate(EVCube9Model[1], glm::vec3(195.0f / 5.0f, 801.6f, 67.0f / 5.0f));
	EVCube9Model[1] = glm::scale(EVCube9Model[1], glm::vec3(1.0f, 0.01f, 1.0f));
	EVCube9Model[2] = glm::translate(EVCube9Model[2], glm::vec3(167.0f / 5.0f, 801.6f, 124.0f / 5.0f));
	EVCube9Model[2] = glm::scale(EVCube9Model[2], glm::vec3(1.0f, 0.01f, 1.0f));



	for (int i = 0; i < 3; i++)
	{
		EVCube1[i].InitBuffers("Cube2.vs", "Cube2.fs", "EV2.jpg");
		EVCube2[i].InitBuffers("Cube2.vs", "Cube2.fs", "EV2.jpg");
		EVCube3[i].InitBuffers("Cube2.vs", "Cube2.fs", "EV2.jpg");
		EVCube4[i].InitBuffers("Cube2.vs", "Cube2.fs", "EV2.jpg");
		EVCube5[i].InitBuffers("Cube2.vs", "Cube2.fs", "EV2.jpg");
		EVCube6[i].InitBuffers("Cube2.vs", "Cube2.fs", "EV2.jpg");
		EVCube7[i].InitBuffers("Cube2.vs", "Cube2.fs", "EV2.jpg");
		EVCube8[i].InitBuffers("Cube2.vs", "Cube2.fs", "EV2.jpg");
		EVCube9[i].InitBuffers("Cube2.vs", "Cube2.fs", "EV2.jpg");
	}


	for (int i = 0; i < 3; i++)
	{
		STCube1[i].InitBuffers("Cube2.vs", "Cube2.fs", "ST.jpg");
		STCube2[i].InitBuffers("Cube2.vs", "Cube2.fs", "ST.jpg");
		STCube3[i].InitBuffers("Cube2.vs", "Cube2.fs", "ST.jpg");
		STCube4[i].InitBuffers("Cube2.vs", "Cube2.fs", "ST.jpg");
		STCube5[i].InitBuffers("Cube2.vs", "Cube2.fs", "ST.jpg");
		STCube6[i].InitBuffers("Cube2.vs", "Cube2.fs", "ST.jpg");
		STCube7[i].InitBuffers("Cube2.vs", "Cube2.fs", "ST.jpg");
		STCube8[i].InitBuffers("Cube2.vs", "Cube2.fs", "ST.jpg");
		STCube9[i].InitBuffers("Cube2.vs", "Cube2.fs", "ST.jpg");
	}

	floorCubeModel[0] = glm::translate(floorCubeModel[0], glm::vec3(148.5f * 0.2f, 0.0f, 10.0f));
	floorCubeModel[0] = glm::rotate(floorCubeModel[0], 45.0f, glm::vec3(1.0f, 0.0f, 0.0f));
	floorCubeModel[0] = glm::scale(floorCubeModel[0], glm::vec3(3.0f, 0.01f, 3.0f));

	floorCubeModel[1] = glm::translate(floorCubeModel[1], glm::vec3(148.5f * 0.2f, 100.0f, 10.0f));
	floorCubeModel[1] = glm::rotate(floorCubeModel[1], 45.0f, glm::vec3(1.0f, 0.0f, 0.0f));
	floorCubeModel[1] = glm::scale(floorCubeModel[1], glm::vec3(3.0f, 0.01f, 3.0f));

	floorCubeModel[2] = glm::translate(floorCubeModel[2], glm::vec3(148.5f * 0.2f, 200.0f, 0.0f));
	floorCubeModel[2] = glm::rotate(floorCubeModel[2], 45.0f, glm::vec3(1.0f, 0.0f, 0.0f));
	floorCubeModel[2] = glm::scale(floorCubeModel[2], glm::vec3(3.0f, 0.01f, 3.0f));

	floorCubeModel[3] = glm::translate(floorCubeModel[3], glm::vec3(148.5f * 0.2f, 300.0f, 0.0f));
	floorCubeModel[3] = glm::rotate(floorCubeModel[3], 45.0f, glm::vec3(1.0f, 0.0f, 0.0f));
	floorCubeModel[3] = glm::scale(floorCubeModel[3], glm::vec3(3.0f, 0.01f, 3.0f));

	floorCubeModel[4] = glm::translate(floorCubeModel[4], glm::vec3(148.5f * 0.2f, 400.0f, 0.0f));
	floorCubeModel[4] = glm::rotate(floorCubeModel[4], 45.0f, glm::vec3(1.0f, 0.0f, 0.0f));
	floorCubeModel[4] = glm::scale(floorCubeModel[4], glm::vec3(3.0f, 0.01f, 3.0f));

	floorCubeModel[5] = glm::translate(floorCubeModel[5], glm::vec3(148.5f * 0.2f, 500.0f, 0.0f));
	floorCubeModel[5] = glm::rotate(floorCubeModel[5], 45.0f, glm::vec3(1.0f, 0.0f, 0.0f));
	floorCubeModel[5] = glm::scale(floorCubeModel[5], glm::vec3(3.0f, 0.01f, 3.0f));

	floorCubeModel[6] = glm::translate(floorCubeModel[6], glm::vec3(148.5f * 0.2f, 600.0f, 0.0f));
	floorCubeModel[6] = glm::rotate(floorCubeModel[6], 45.0f, glm::vec3(1.0f, 0.0f, 0.0f));
	floorCubeModel[6] = glm::scale(floorCubeModel[6], glm::vec3(3.0f, 0.01f, 3.0f));

	floorCubeModel[7] = glm::translate(floorCubeModel[7], glm::vec3(148.5f * 0.2f, 700.0f, 0.0f));
	floorCubeModel[7] = glm::rotate(floorCubeModel[7], 45.0f, glm::vec3(1.0f, 0.0f, 0.0f));
	floorCubeModel[7] = glm::scale(floorCubeModel[7], glm::vec3(3.0f, 0.01f, 3.0f));

	floorCubeModel[8] = glm::translate(floorCubeModel[8], glm::vec3(148.5f * 0.2f, 800.0f, 0.0f));
	floorCubeModel[8] = glm::rotate(floorCubeModel[8], 45.0f, glm::vec3(1.0f, 0.0f, 0.0f));
	floorCubeModel[8] = glm::scale(floorCubeModel[8], glm::vec3(3.0f, 0.01f, 3.0f));


	floorCube[0].InitBuffers("Cube2.vs", "Cube2.fs", "1ft.jpg");
	floorCube[1].InitBuffers("Cube2.vs", "Cube2.fs", "2ft.jpg");
	floorCube[2].InitBuffers("Cube2.vs", "Cube2.fs", "3ft.jpg");
	floorCube[3].InitBuffers("Cube2.vs", "Cube2.fs", "4ft.jpg");
	floorCube[4].InitBuffers("Cube2.vs", "Cube2.fs", "5ft.jpg");
	floorCube[5].InitBuffers("Cube2.vs", "Cube2.fs", "6ft.jpg");
	floorCube[6].InitBuffers("Cube2.vs", "Cube2.fs", "7ft.jpg");
	floorCube[7].InitBuffers("Cube2.vs", "Cube2.fs", "8ft.jpg");
	floorCube[8].InitBuffers("Cube2.vs", "Cube2.fs", "9ft.jpg");

	STCube1Model[0] = glm::translate(STCube1Model[0], glm::vec3(137.0f * 0.2f, 1.6f, 111.0f * 0.2f));
	STCube1Model[0] = glm::scale(STCube1Model[0], glm::vec3(2.0f, 0.01f, 0.6f));
	STCube1Model[1] = glm::translate(STCube1Model[1], glm::vec3(100.0f * 0.2f, 1.6f, 127.0f * 0.2f));
	STCube1Model[1] = glm::scale(STCube1Model[1], glm::vec3(1.0f, 0.01f, 1.0f));
	STCube1Model[2] = glm::translate(STCube1Model[2], glm::vec3(162.5f * 0.2f, 1.6f, 141.5f * 0.2f));
	STCube1Model[2] = glm::scale(STCube1Model[2], glm::vec3(1.4f, 0.01f, 1.4f));
	STCube1Model[3] = glm::translate(STCube1Model[3], glm::vec3(188.5f * 0.2f, 1.6f, 167.5f * 0.2f));
	STCube1Model[3] = glm::scale(STCube1Model[3], glm::vec3(1.0f, 0.01f, 1.0f));

	STCube2Model[0] = glm::translate(STCube2Model[0], glm::vec3(168.0f / 5.0f, 101.6f, 148.0f / 5.0f));
	STCube2Model[0] = glm::scale(STCube2Model[0], glm::vec3(1.5f, 0.01f, 1.5f));
	STCube2Model[1] = glm::translate(STCube2Model[1], glm::vec3(101.5f / 5.0f, 101.6f, 127.5f / 5.0f));
	STCube2Model[1] = glm::scale(STCube2Model[1], glm::vec3(1.0f, 0.01f, 1.0f));
	STCube2Model[2] = glm::translate(STCube2Model[2], glm::vec3(189.0f / 5.0f, 101.6f, 168.5f / 5.0f));
	STCube2Model[2] = glm::scale(STCube2Model[2], glm::vec3(1.0f, 0.01f, 1.0f));

	STCube3Model[0] = glm::translate(STCube3Model[0], glm::vec3(98.0f * 0.2f, 201.6f, 83.5f * 0.2f));
	STCube3Model[0] = glm::scale(STCube3Model[0], glm::vec3(1.0f, 0.01f, 1.0f));
	STCube3Model[1] = glm::translate(STCube3Model[1], glm::vec3(186.5f * 0.2f, 201.6f, 123.0f * 0.2f));
	STCube3Model[1] = glm::scale(STCube3Model[1], glm::vec3(1.0f, 0.01f, 1.0f));
	STCube3Model[2] = glm::translate(STCube3Model[2], glm::vec3(167.5f * 0.2f, 201.6f, 95.5f * 0.2f));
	STCube3Model[2] = glm::scale(STCube3Model[2], glm::vec3(2.0f, 0.01f, 0.6f));
	STCube3Model[3] = glm::translate(STCube3Model[3], glm::vec3(170.5f * 0.2f, 201.6f, 110.5f * 0.2f));
	STCube3Model[3] = glm::scale(STCube3Model[3], glm::vec3(1.7f, 0.01f, 0.6f));

	STCube4Model[0] = glm::translate(STCube4Model[0], glm::vec3(98.0f * 0.2f, 301.6f, 83.5f * 0.2f));
	STCube4Model[0] = glm::scale(STCube4Model[0], glm::vec3(1.0f, 0.01f, 1.0f));
	STCube4Model[1] = glm::translate(STCube4Model[1], glm::vec3(186.5f * 0.2f, 301.6f, 123.0f * 0.2f));
	STCube4Model[1] = glm::scale(STCube4Model[1], glm::vec3(1.0f, 0.01f, 1.0f));
	STCube4Model[2] = glm::translate(STCube4Model[2], glm::vec3(167.5f * 0.2f, 301.6f, 95.5f * 0.2f));
	STCube4Model[2] = glm::scale(STCube4Model[2], glm::vec3(2.0f, 0.01f, 0.6f));
	STCube4Model[3] = glm::translate(STCube4Model[3], glm::vec3(170.5f * 0.2f, 301.6f, 110.0f * 0.2f));
	STCube4Model[3] = glm::scale(STCube4Model[3], glm::vec3(1.7f, 0.01f, 0.6f));

	STCube5Model[0] = glm::translate(STCube5Model[0], glm::vec3(98.0f * 0.2f, 401.6f, 83.5f * 0.2f));
	STCube5Model[0] = glm::scale(STCube5Model[0], glm::vec3(1.0f, 0.01f, 1.0f));
	STCube5Model[1] = glm::translate(STCube5Model[1], glm::vec3(186.5f * 0.2f, 401.6f, 123.0f * 0.2f));
	STCube5Model[1] = glm::scale(STCube5Model[1], glm::vec3(1.0f, 0.01f, 1.0f));
	STCube5Model[2] = glm::translate(STCube5Model[2], glm::vec3(133.0f * 0.2f, 401.6f, 95.5f * 0.2f));
	STCube5Model[2] = glm::scale(STCube5Model[2], glm::vec3(2.0f, 0.01f, 0.5f));
	STCube5Model[3] = glm::translate(STCube5Model[3], glm::vec3(161.5f * 0.2f, 401.6f, 110.5f * 0.2f));
	STCube5Model[3] = glm::scale(STCube5Model[3], glm::vec3(2.0f, 0.01f, 0.5f));

	STCube6Model[0] = glm::translate(STCube6Model[0], glm::vec3(98.0f * 0.2f, 501.6f, 83.5f * 0.2f));
	STCube6Model[0] = glm::scale(STCube6Model[0], glm::vec3(1.0f, 0.01f, 1.0f));
	STCube6Model[1] = glm::translate(STCube6Model[1], glm::vec3(186.5f * 0.2f, 501.6f, 123.0f * 0.2f));
	STCube6Model[1] = glm::scale(STCube6Model[1], glm::vec3(1.0f, 0.01f, 1.0f));
	STCube6Model[2] = glm::translate(STCube6Model[2], glm::vec3(130.0f * 0.2f, 501.6f, 110.5f * 0.2f));
	STCube6Model[2] = glm::scale(STCube6Model[2], glm::vec3(2.0f, 0.01f, 0.6f));
	STCube6Model[3] = glm::translate(STCube6Model[3], glm::vec3(130.0f * 0.2f, 501.6f, 95.0f * 0.2f));
	STCube6Model[3] = glm::scale(STCube6Model[3], glm::vec3(2.0f, 0.01f, 0.6f));

	STCube7Model[0] = glm::translate(STCube7Model[0], glm::vec3(98.0f / 5.0f, 601.6f, 83.5f / 5.0f));
	STCube7Model[0] = glm::scale(STCube7Model[0], glm::vec3(1.0f, 0.01f, 1.0f));
	STCube7Model[1] = glm::translate(STCube7Model[1], glm::vec3(186.5f / 5.0f, 601.6f, 123.0f / 5.0f));
	STCube7Model[1] = glm::scale(STCube7Model[1], glm::vec3(1.0f, 0.01f, 1.0f));
	STCube7Model[2] = glm::translate(STCube7Model[2], glm::vec3(164.0f / 5.0f, 601.6f, 95.0f / 5.0f));
	STCube7Model[2] = glm::scale(STCube7Model[2], glm::vec3(2.0f, 0.01f, 0.6f));
	STCube7Model[3] = glm::translate(STCube7Model[3], glm::vec3(133.0f / 5.0f, 601.6f, 95.0f / 5.0f));
	STCube7Model[3] = glm::scale(STCube7Model[3], glm::vec3(2.0f, 0.01f, 0.6f));

	STCube8Model[0] = glm::translate(STCube8Model[0], glm::vec3(98.0f / 5.0f, 701.6f, 83.5f / 5.0f));
	STCube8Model[0] = glm::scale(STCube8Model[0], glm::vec3(1.0f, 0.01f, 1.0f));
	STCube8Model[1] = glm::translate(STCube8Model[1], glm::vec3(186.5f / 5.0f, 701.6f, 123.0f / 5.0f));
	STCube8Model[1] = glm::scale(STCube8Model[1], glm::vec3(1.0f, 0.01f, 1.0f));
	STCube8Model[2] = glm::translate(STCube8Model[2], glm::vec3(165.0f / 5.0f, 701.6f, 95.0f / 5.0f));
	STCube8Model[2] = glm::scale(STCube8Model[2], glm::vec3(2.0f, 0.01f, 0.6f));
	STCube8Model[3] = glm::translate(STCube8Model[3], glm::vec3(165.0f / 5.0f, 701.6f, 110.0f / 5.0f));
	STCube8Model[3] = glm::scale(STCube8Model[3], glm::vec3(2.0f, 0.01f, 0.6f));


	STCube9Model[0] = glm::translate(STCube9Model[0], glm::vec3(98.0f / 5.0f, 801.6f, 83.5f / 5.0f));
	STCube9Model[0] = glm::scale(STCube9Model[0], glm::vec3(1.0f, 0.01f, 1.0f));
	STCube9Model[1] = glm::translate(STCube9Model[1], glm::vec3(186.5f / 5.0f, 801.6f, 123.0f / 5.0f));
	STCube9Model[1] = glm::scale(STCube9Model[1], glm::vec3(1.0f, 0.01f, 1.0f));
	STCube9Model[2] = glm::translate(STCube9Model[2], glm::vec3(163.0f / 5.0f, 801.6f, 110.0f / 5.0f));
	STCube9Model[2] = glm::scale(STCube9Model[2], glm::vec3(2.0f, 0.01f, 0.6f));

	STCube1[3].InitBuffers("Cube2.vs", "Cube2.fs", "ST.jpg");
	STCube3[3].InitBuffers("Cube2.vs", "Cube2.fs", "ST.jpg");
	STCube4[3].InitBuffers("Cube2.vs", "Cube2.fs", "ST.jpg");
	STCube5[3].InitBuffers("Cube2.vs", "Cube2.fs", "ST.jpg");
	STCube6[3].InitBuffers("Cube2.vs", "Cube2.fs", "ST.jpg");
	STCube7[3].InitBuffers("Cube2.vs", "Cube2.fs", "ST.jpg");
	STCube8[3].InitBuffers("Cube2.vs", "Cube2.fs", "ST.jpg");
}

void DSCamera::RenderCamera()
{

	mViewMat = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);

	firstFloor.renderModel(firstFloorModel, mViewMat, mProjMat);
	secondFloor.renderModel(secondFloorModel, mViewMat, mProjMat);
	thirdFloor.renderModel(thirdFloorModel, mViewMat, mProjMat);
	fourthFloor.renderModel(fourthFloorModel, mViewMat, mProjMat);
	fifthFloor.renderModel(fifthFloorModel, mViewMat, mProjMat);
	sixthFloor.renderModel(sixthFloorModel, mViewMat, mProjMat);
	seventhFloor.renderModel(seventhFloorModel, mViewMat, mProjMat);
	eighthFloor.renderModel(eighthFloorModel, mViewMat, mProjMat);
	ninthFloor.renderModel(ninthFloorModel, mViewMat, mProjMat);
	
	for (vector<int>::size_type i = 0; i < move_point.size() - 1; i++) {
		lineArr[i].RenderBuffers(lineModel, mViewMat, mProjMat);
	}

	pointer.RenderBuffers(pointerModel, mViewMat, mProjMat);

	if (move_time != move_time_end) {
		if (abs(movePointArr[move_time].x - lastPointArr[move_time].x) > 0.01 
			|| abs(movePointArr[move_time].z - lastPointArr[move_time].z) > 0.01 
			|| abs(movePointArr[move_time].y - lastPointArr[move_time].y) > 0.1) 
		{
			movePointArr[move_time].x += (lastPointArr[move_time].x - startPointArr[move_time].x) / 50;
			movePointArr[move_time].y += (lastPointArr[move_time].y - startPointArr[move_time].y) / 50;
			movePointArr[move_time].z += (lastPointArr[move_time].z - startPointArr[move_time].z) / 50;

			lineArr[move_time].InitBuffers("Line.vs", "Line.fs", startPointArr[move_time], movePointArr[move_time]);

			pointer.InitBuffers("Pointer.vs", "Pointer.fs", movePointArr[move_time]);

			cameraPos = glm::vec3(movePointArr[move_time].x, movePointArr[move_time].y + 40.0f, movePointArr[move_time].z + 30.0f);
			cameraFront = movePointArr[move_time] - cameraPos;
		}
		else {
			move_time++;
		}
	}

	for (int i = 0; i < 3; i++)
	{
		EVCube1[i].RenderBuffers(EVCube1Model[i], mViewMat, mProjMat);
		EVCube2[i].RenderBuffers(EVCube2Model[i], mViewMat, mProjMat);
		EVCube3[i].RenderBuffers(EVCube3Model[i], mViewMat, mProjMat);
		EVCube4[i].RenderBuffers(EVCube4Model[i], mViewMat, mProjMat);
		EVCube5[i].RenderBuffers(EVCube5Model[i], mViewMat, mProjMat);
		EVCube6[i].RenderBuffers(EVCube6Model[i], mViewMat, mProjMat);
		EVCube7[i].RenderBuffers(EVCube7Model[i], mViewMat, mProjMat);
		EVCube8[i].RenderBuffers(EVCube8Model[i], mViewMat, mProjMat);
		EVCube9[i].RenderBuffers(EVCube9Model[i], mViewMat, mProjMat);
	}
	for (int i = 0; i < 3; i++)
	{
		STCube1[i].RenderBuffers(STCube1Model[i], mViewMat, mProjMat);
		STCube2[i].RenderBuffers(STCube2Model[i], mViewMat, mProjMat);
		STCube3[i].RenderBuffers(STCube3Model[i], mViewMat, mProjMat);
		STCube4[i].RenderBuffers(STCube4Model[i], mViewMat, mProjMat);
		STCube5[i].RenderBuffers(STCube5Model[i], mViewMat, mProjMat);
		STCube6[i].RenderBuffers(STCube6Model[i], mViewMat, mProjMat);
		STCube7[i].RenderBuffers(STCube7Model[i], mViewMat, mProjMat);
		STCube8[i].RenderBuffers(STCube8Model[i], mViewMat, mProjMat);
		STCube9[i].RenderBuffers(STCube9Model[i], mViewMat, mProjMat);
	}

	STCube1[3].RenderBuffers(STCube1Model[3], mViewMat, mProjMat);
	STCube3[3].RenderBuffers(STCube3Model[3], mViewMat, mProjMat);
	STCube4[3].RenderBuffers(STCube4Model[3], mViewMat, mProjMat);
	STCube5[3].RenderBuffers(STCube5Model[3], mViewMat, mProjMat);
	STCube6[3].RenderBuffers(STCube6Model[3], mViewMat, mProjMat);
	STCube7[3].RenderBuffers(STCube7Model[3], mViewMat, mProjMat);
	STCube8[3].RenderBuffers(STCube8Model[3], mViewMat, mProjMat);

	for (int i = 0; i < 9; i++)
	{
		floorCube[i].RenderBuffers(floorCubeModel[i], mViewMat, mProjMat);
	}


}

void DSCamera::ReleaseCamera()
{
	for (vector<int>::size_type i = 0; i < move_point.size() - 1; i++) {
		lineArr[i].ReleaseBuffers();
	}
	pointer.ReleaseBuffers();

	firstFloor.releaseModel();
	seventhFloor.releaseModel();
}


void DSCamera::KeyInput(int key, int action, int mods)
{
	
	float cameraSpeed = 0.5f;
	

	if (key == GLFW_KEY_V && action == GLFW_PRESS)
	{
		now_where++;
		if (now_where == floor_all.size())
			now_where = 0;
		int stair = floor_all[now_where] - 1;
		cameraPos = cameraPos_arr[stair];
		cameraFront = glm::vec3(0.0f, -1.0f, -0.6f);
		cout << now_where << "  " << move_point.size() << endl;
	}
	//ī�޶� �¿��̵�
	if (key == GLFW_KEY_W)
	{
		cameraPos.z -= cameraSpeed;
	}
	if (key == GLFW_KEY_S)
	{
		cameraPos.z += cameraSpeed;
	}
	if (key == GLFW_KEY_A)
	{
		cameraPos.x -= cameraSpeed;
	}
	if (key == GLFW_KEY_D)
	{
		cameraPos.x += cameraSpeed;
	}

	//ī�޶� ���� �̵�
	if (key == GLFW_KEY_R)
	{
		cameraPos.y += cameraSpeed;
	}
	if (key == GLFW_KEY_F)
	{
		cameraPos.y -= cameraSpeed;
	}

	//ī�޶� Ȯ��
	if (key == GLFW_KEY_T)
	{
		cameraPos += cameraSpeed * cameraFront * 0.3f;
	}
	if (key == GLFW_KEY_G)
	{
		cameraPos -= cameraSpeed * cameraFront * 0.3f;
	}

	//���� �̵�
	if (key == GLFW_KEY_1)
	{
		cameraPos = glm::vec3(28.0f, 40.0f, 50.0f);
		cameraFront = glm::vec3(0.0f, -1.0f, -0.6f);
	}
	if (key == GLFW_KEY_2)
	{
		cameraPos = glm::vec3(28.0f, 140.0f, 50.0f);
		cameraFront = glm::vec3(0.0f, -1.0f, -0.6f);
	}
	if (key == GLFW_KEY_3)
	{
		cameraPos = glm::vec3(28.0f, 240.0f, 40.0f);
		cameraFront = glm::vec3(0.0f, -1.0f, -0.6f);
	}
	if (key == GLFW_KEY_4)
	{
		cameraPos = glm::vec3(28.0f, 340.0f, 40.0f);
		cameraFront = glm::vec3(0.0f, -1.0f, -0.6f);
	}
	if (key == GLFW_KEY_5)
	{
		cameraPos = glm::vec3(28.0f, 440.0f, 40.0f);
		cameraFront = glm::vec3(0.0f, -1.0f, -0.6f);
	}
	if (key == GLFW_KEY_6)
	{
		cameraPos = glm::vec3(28.0f, 540.0f, 40.0f);
		cameraFront = glm::vec3(0.0f, -1.0f, -0.6f);
	}
	if (key == GLFW_KEY_7)
	{
		cameraPos = glm::vec3(28.0f, 640.0f, 40.0f);
		cameraFront = glm::vec3(0.0f, -1.0f, -0.6f);
	}
	if (key == GLFW_KEY_8)
	{
		cameraPos = glm::vec3(28.0f, 740.0f, 40.0f);
		cameraFront = glm::vec3(0.0f, -1.0f, -0.6f);
	}
	if (key == GLFW_KEY_9)
	{
		cameraPos = glm::vec3(28.0f, 840.0f, 40.0f);
		cameraFront = glm::vec3(0.0f, -1.0f, -0.6f);
	}


}

void DSCamera::MouseInput(float xpos, float ypos)
{
}
