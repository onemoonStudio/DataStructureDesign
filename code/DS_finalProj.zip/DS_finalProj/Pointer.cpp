#include "Pointer.h"



Pointer::Pointer()
{
}


Pointer::~Pointer()
{
}

void Pointer::InitBuffers(const char* vsFile, const char* fsFile, glm::vec3 point) {

	mShader.InitShader(vsFile, fsFile);

	float mVertices[3] = {
		point.x, point.y, point.z
	};

	glPointSize(20.0f);

	glGenVertexArrays(1, &mVAO);
	glGenBuffers(1, &mVBO);

	glBindVertexArray(mVAO);
	glBindBuffer(GL_ARRAY_BUFFER, mVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(mVertices), mVertices, GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);

}

void Pointer::RenderBuffers(glm::mat4 model, glm::mat4 view, glm::mat4 proj) {

	glUseProgram(mShader.program);

	GLuint modelLoc = glGetUniformLocation(mShader.program, "model");
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	GLuint viewLoc = glGetUniformLocation(mShader.program, "view");
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));

	GLuint projLoc = glGetUniformLocation(mShader.program, "proj");
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(proj));

	glBindVertexArray(mVAO);
	glDrawArrays(GL_POINTS, 0, 1);
	glBindVertexArray(0);

}

void Pointer::ReleaseBuffers() {

	glDeleteVertexArrays(1, &mVAO);
	glDeleteBuffers(1, &mVBO);

}