#pragma once
#pragma comment(lib,"Glfw3.lib")
#pragma comment(lib,"Glew32.lib")
#pragma comment(lib,"Glew32s.lib")

class Application
{
public:
	Application();
	~Application();

public:
	virtual void InitApp() = 0;
	virtual void RenderApp() = 0;
	virtual void ReleaseApp() = 0;

	virtual void KeyInput(int key, int action, int mods) = 0;
	virtual void MouseInput(double xpos, double ypos) = 0;

};

