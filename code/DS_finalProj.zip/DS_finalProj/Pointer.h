#pragma once
#pragma comment(lib,"Glfw3.lib")
#pragma comment(lib,"Glew32.lib")
#pragma comment(lib,"Glew32s.lib")

#include "TextureM.h"

class Pointer
{
public:
	Pointer();
	~Pointer();

	void InitBuffers(const char* vsFile, const char* fsFile, glm::vec3 point);
	void RenderBuffers(glm::mat4 model, glm::mat4 view, glm::mat4 proj);
	void ReleaseBuffers();

public:
	GLuint mVAO, mVBO;
	Shader mShader;

};

