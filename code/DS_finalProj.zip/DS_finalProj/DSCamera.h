#pragma once
#pragma comment(lib,"Glfw3.lib")
#pragma comment(lib,"Glew32.lib")
#pragma comment(lib,"Glew32s.lib")

#include "objModel.h"
#include "Pointer.h"
#include "Line.h"
#include "Cube.h"
#include <vector>
#include <tuple>

//#include "AlgoTeam.h"

class DSCamera
{
public:
	DSCamera();
	~DSCamera();

	void InitCamera(vector<pair<float, float>> move_point__, vector<int>floor__);
	void RenderCamera();
	void ReleaseCamera();

	void KeyInput(int key, int action, int mods);
	void MouseInput(float xpos, float ypos);

public:
	glm::vec3 cameraPos;
	glm::vec3 cameraFront;
	glm::vec3 cameraUp;

	glm::mat4 mModelMat;
	glm::mat4 mViewMat;
	glm::mat4 mProjMat;

	vector<tuple<float, float, float>> move_point;
	glm::vec3 startPointArr[100];
	glm::vec3 lastPointArr[100];
	glm::vec3 movePointArr[100];
	int move_time, move_time_end;
	int floor;
	vector<int> floor_all;
	int now_where = -1;
public:
	Line lineArr[100];
	glm::mat4 lineModel;

	Pointer pointer;
	glm::mat4 pointerModel;

	objModel firstFloor;
	glm::mat4 firstFloorModel;
	Cube EVCube1[10];
	glm::mat4 EVCube1Model[10];
	Cube STCube1[10];
	glm::mat4 STCube1Model[10];

	objModel secondFloor;
	glm::mat4 secondFloorModel;
	Cube EVCube2[10];
	glm::mat4 EVCube2Model[10];
	Cube STCube2[10];
	glm::mat4 STCube2Model[10];

	objModel thirdFloor;
	glm::mat4 thirdFloorModel;
	Cube EVCube3[10];
	glm::mat4 EVCube3Model[10];
	Cube STCube3[10];
	glm::mat4 STCube3Model[10];

	objModel fourthFloor;
	glm::mat4 fourthFloorModel;
	Cube EVCube4[10];
	glm::mat4 EVCube4Model[10];
	Cube STCube4[10];
	glm::mat4 STCube4Model[10];

	objModel fifthFloor;
	glm::mat4 fifthFloorModel;
	Cube EVCube5[10];
	glm::mat4 EVCube5Model[10];
	Cube STCube5[10];
	glm::mat4 STCube5Model[10];

	objModel sixthFloor;
	glm::mat4 sixthFloorModel;
	Cube EVCube6[10];
	glm::mat4 EVCube6Model[10];
	Cube STCube6[10];
	glm::mat4 STCube6Model[10];

	objModel seventhFloor;
	glm::mat4 seventhFloorModel;
	Cube EVCube7[10];
	glm::mat4 EVCube7Model[10];
	Cube STCube7[10];
	glm::mat4 STCube7Model[10];

	objModel eighthFloor;
	glm::mat4 eighthFloorModel;
	Cube EVCube8[10];
	glm::mat4 EVCube8Model[10];
	Cube STCube8[10];
	glm::mat4 STCube8Model[10];

	objModel ninthFloor;
	glm::mat4 ninthFloorModel;
	Cube EVCube9[10];
	glm::mat4 EVCube9Model[10];
	Cube STCube9[10];
	glm::mat4 STCube9Model[10];

	Cube floorCube[9];
	glm::mat4 floorCubeModel[9];

	//AlgoTeam algo;

	glm::vec3 cameraPos_arr[10] = {
		glm::vec3(28.0f, 40.0f, 50.0f),
		glm::vec3(28.0f, 140.0f, 50.0f),
		glm::vec3(28.0f, 240.0f, 40.0f),
		glm::vec3(28.0f, 340.0f, 40.0f),
		glm::vec3(28.0f, 440.0f, 40.0f),
		glm::vec3(28.0f, 540.0f, 40.0f),
		glm::vec3(28.0f, 640.0f, 40.0f),
		glm::vec3(28.0f, 740.0f, 40.0f),
		glm::vec3(28.0f, 840.0f, 40.0f)
	};

};

