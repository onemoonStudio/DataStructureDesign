#pragma once

#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>

using namespace std;

#define MAX_intersection 239
#define MAX_class 436
#define MAX_elevator 122
#define MAX_stair 48

class AlgoTeam
{
public:
	AlgoTeam();
	~AlgoTeam();

public:

	void pop_mat(string inputString[2000], int a);
	void print_mat();
	int convert_day(string day);
	int convert_time(string time);
	void tmp_storage(string *inputString_a, string *inputString_b, string *inputString_c, string *inputString_d);
	void intersection_node_storage();
	float **intersection_dist_storage(string start, string finish, vector<string> node, vector<pair<float, float>> coordinate);
	float **intersection_dist_storage_2(string start, string finish, vector<string> node, vector<pair<float, float>> coordinate);
	float **intersection_dist_storage_3(string start, string finish, vector<string> node, vector<pair<float, float>> coordinate);
	float **intersection_dist_storage_4(string start, string finish, vector<string> node, vector<pair<float, float>> coordinate);
	float **intersection_dist_storage_5(string start, string finish, vector<string> node, vector<pair<float, float>> coordinate);
	float **intersection_dist_storage_6(string start, string finish, vector<string> node, vector<pair<float, float>> coordinate);
	float **intersection_dist_storage_7(string start, string finish, vector<string> node, vector<pair<float, float>> coordinate);
	float **intersection_dist_storage_8(string start, string finish, vector<string> node, vector<pair<float, float>> coordinate);
	float **intersection_dist_storage_9(string start, string finish, vector<string> node, vector<pair<float, float>> coordinate);
	float **intersection_dist_storage_10(string start, string finish, vector<string> node, vector<pair<float, float>> coordinate);
	float **intersection_dist_storage_11(string start, string finish, vector<string> node, vector<pair<float, float>> coordinate);
	float **intersection_dist_storage_12(string start, string finish, vector<string> node, vector<pair<float, float>> coordinate);
	float **intersection_dist_storage_13(string start, string finish, vector<string> node, vector<pair<float, float>> coordinate);
	float **intersection_dist_storage_14(string start, string finish, vector<string> node, vector<pair<float, float>> coordinate);
	float **intersection_dist_storage_15(string start, string finish, vector<string> node, vector<pair<float, float>> coordinate);
	float **intersection_dist_storage_16(string start, string finish, vector<string> node, vector<pair<float, float>> coordinate);

	int minDistance(float *dist, bool *sptSet);
	void printSolution(float *dist, vector<vector<int>> path, int n, int finish);
	vector<pair<float, float>> dijkstra_path(float **graph, vector<pair<float, float>> list, int src, int finish);
	float dijkstra_dist(float **graph, vector<pair<float, float>> list, int src, int finish);
	void same_floor(string start, string finish, vector<pair<float, float>> list, float input_start_coord[1][2], float input_finish_coord[1][2], vector<string> intersection_node);
	void not_same_floor(int tmp, string start, string middle, string middle2, string finish, vector<pair<float, float>> list, vector<pair<float, float>> list2, float input_start_coord[1][2], float input_middle1_coord[1][2], float input_middle2_coord[1][2], float input_finish_coord[1][2], vector<string> intersection_node, vector<string> intersection_node_2);
	void not_same_floor2(int tmp, string start, string middle, string middle2, string finish, vector<pair<float, float>> list, vector<pair<float, float>> list2, float input_start_coord[1][2], float input_middle1_coord[1][2], float input_middle2_coord[1][2], float input_finish_coord[1][2], vector<string> intersection_node, vector<string> intersection_node_2);
	void not_same_floor3(int tmp, string start, string middle, string middle2, string finish, vector<pair<float, float>> list, vector<pair<float, float>> list2, float input_start_coord[1][2], float input_middle1_coord[1][2], float input_middle2_coord[1][2], float input_finish_coord[1][2], vector<string> intersection_node, vector<string> intersection_node_2);
	void not_same_floor4(string start, string middle, string middle2, string middle3, string middle4, string finish, vector<pair<float, float>> list, vector<pair<float, float>> list2, vector<pair<float, float>> list3, float input_start_coord[1][2], float input_middle1_coord[1][2], float input_middle2_coord[1][2], float input_middle3_coord[1][2], float input_middle4_coord[1][2], float input_finish_coord[1][2], vector<string> intersection_node, vector<string> intersection_node_2, vector<string> intersection_node_3);
	void not_same_floor5(string start, string middle, string middle2, string middle3, string middle4, string finish, vector<pair<float, float>> list, vector<pair<float, float>> list2, vector<pair<float, float>> list3, float input_start_coord[1][2], float input_middle1_coord[1][2], float input_middle2_coord[1][2], float input_middle3_coord[1][2], float input_middle4_coord[1][2], float input_finish_coord[1][2], vector<string> intersection_node, vector<string> intersection_node_2, vector<string> intersection_node_3);
	void not_same_floor6(string start, string middle, string middle2, string middle3, string middle4, string finish, vector<pair<float, float>> list, vector<pair<float, float>> list2, vector<pair<float, float>> list3, float input_start_coord[1][2], float input_middle1_coord[1][2], float input_middle2_coord[1][2], float input_middle3_coord[1][2], float input_middle4_coord[1][2], float input_finish_coord[1][2], vector<string> intersection_node, vector<string> intersection_node_2, vector<string> intersection_node_3);
	void not_same_floor7(string start, string middle, string middle2, string middle3, string middle4, string finish, vector<pair<float, float>> list, vector<pair<float, float>> list2, vector<pair<float, float>> list3, float input_start_coord[1][2], float input_middle1_coord[1][2], float input_middle2_coord[1][2], float input_middle3_coord[1][2], float input_middle4_coord[1][2], float input_finish_coord[1][2], vector<string> intersection_node, vector<string> intersection_node_2, vector<string> intersection_node_3);
	void not_same_floor8(string start, string middle, string middle2, string middle3, string middle4, string finish, vector<pair<float, float>> list, vector<pair<float, float>> list2, vector<pair<float, float>> list3, float input_start_coord[1][2], float input_middle1_coord[1][2], float input_middle2_coord[1][2], float input_middle3_coord[1][2], float input_middle4_coord[1][2], float input_finish_coord[1][2], vector<string> intersection_node, vector<string> intersection_node_2, vector<string> intersection_node_3);
	void not_same_floor9(string start, string middle, string middle2, string middle3, string middle4, string finish, vector<pair<float, float>> list, vector<pair<float, float>> list2, vector<pair<float, float>> list3, float input_start_coord[1][2], float input_middle1_coord[1][2], float input_middle2_coord[1][2], float input_middle3_coord[1][2], float input_middle4_coord[1][2], float input_finish_coord[1][2], vector<string> intersection_node, vector<string> intersection_node_2, vector<string> intersection_node_3);
	void not_same_floor10(string start, string middle, string middle2, string middle3, string middle4, string finish, vector<pair<float, float>> list, vector<pair<float, float>> list2, vector<pair<float, float>> list3, float input_start_coord[1][2], float input_middle1_coord[1][2], float input_middle2_coord[1][2], float input_middle3_coord[1][2], float input_middle4_coord[1][2], float input_finish_coord[1][2], vector<string> intersection_node, vector<string> intersection_node_2, vector<string> intersection_node_3);
	void not_same_floor11(string start, string middle, string middle2, string middle3, string middle4, string finish, vector<pair<float, float>> list, vector<pair<float, float>> list2, vector<pair<float, float>> list3, float input_start_coord[1][2], float input_middle1_coord[1][2], float input_middle2_coord[1][2], float input_middle3_coord[1][2], float input_middle4_coord[1][2], float input_finish_coord[1][2], vector<string> intersection_node, vector<string> intersection_node_2, vector<string> intersection_node_3);
	void not_same_floor12(string start, string middle, string middle2, string middle3, string middle4, string finish, vector<pair<float, float>> list, vector<pair<float, float>> list2, vector<pair<float, float>> list3, float input_start_coord[1][2], float input_middle1_coord[1][2], float input_middle2_coord[1][2], float input_middle3_coord[1][2], float input_middle4_coord[1][2], float input_finish_coord[1][2], vector<string> intersection_node, vector<string> intersection_node_2, vector<string> intersection_node_3);

	vector<pair<float, float>> r_path(vector<pair<float, float>> path, vector<pair<float, float>> path3, vector<pair<float, float>> path5, float dist, float dist3, float dist5);
	float r_dist(float dist, float dist3, float dist5);

	vector<pair<float, float>> my_result();

public:

	string day[6] = { "��", "ȭ", "��", "��", "��", "��" };

	int population[10][4][6][57]; //[��][section][����][�ð�] �����α� ������ marix

	//3���� ���������� Ȥ�� 3���� ����� �̿��� path, dist ���� ���� -> result���� ���� ���� ��� �����Ұ���
	vector<pair<float, float>> path, path2, path3, path4, path5, path6, path7, path8, path9, path_tmp1, path_tmp2, result_path;
	float dist, dist2, dist3, dist4, dist5, dist6, dist7, dist8, dist9, result_dist;
	//�� �̵� ����
	vector<int> floor_st;


	//csv���� �޾ƿ� data ������ matrix
	string intersection_tmp[MAX_intersection][7];
	string class_tmp[MAX_class][7];
	string elevator_tmp[MAX_elevator][7];
	string stair_tmp[MAX_stair][7];


	//�� ���� ������ ��� ��ȣ ����, ��ǥ ���� ���� ����
	vector<string> intersection_node_B6;
	vector<pair<float, float>> intersection_coordinate_B6;
	vector<string> intersection_node_B5;
	vector<pair<float, float>> intersection_coordinate_B5;
	vector<string> intersection_node_B4;
	vector<pair<float, float>> intersection_coordinate_B4;
	vector<string> intersection_node_B3;
	vector<pair<float, float>> intersection_coordinate_B3;
	vector<string> intersection_node_B2;
	vector<pair<float, float>> intersection_coordinate_B2;
	vector<string> intersection_node_B1;
	vector<pair<float, float>> intersection_coordinate_B1;
	vector<string> intersection_node_1F;
	vector<pair<float, float>> intersection_coordinate_1F;
	vector<string> intersection_node_2F;
	vector<pair<float, float>> intersection_coordinate_2F;
	vector<string> intersection_node_3F;
	vector<pair<float, float>> intersection_coordinate_3F;
	vector<string> intersection_node_4F;
	vector<pair<float, float>> intersection_coordinate_4F;
	vector<string> intersection_node_5F;
	vector<pair<float, float>> intersection_coordinate_5F;
	vector<string> intersection_node_6F;
	vector<pair<float, float>> intersection_coordinate_6F;
	vector<string> intersection_node_7F;
	vector<pair<float, float>> intersection_coordinate_7F;
	vector<string> intersection_node_8F;
	vector<pair<float, float>> intersection_coordinate_8F;
	vector<string> intersection_node_9F;
	vector<pair<float, float>> intersection_coordinate_9F;
	vector<string> intersection_node_10F;
	vector<pair<float, float>> intersection_coordinate_10F;
	vector<string> intersection_node_11F;
	vector<pair<float, float>> intersection_coordinate_11F;
	vector<string> intersection_node_12F;
	vector<pair<float, float>> intersection_coordinate_12F;
	
};

