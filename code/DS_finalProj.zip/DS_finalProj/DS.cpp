#include "DS.h"


DS::DS(vector<pair<float,float>> move_point_pair, vector<int> floor)
{
	for (vector<int>::size_type i = 0; i < move_point_pair.size(); i++)
		move_point__.push_back(make_pair(move_point_pair[i].first, move_point_pair[i].second));
	
	for (vector<int>::size_type i = 0; i < floor.size(); i++) {
		move_floor.push_back(floor[i]);
	}
}


DS::~DS()
{
}


void DS::InitApp()
{
	DScam.InitCamera(move_point__, move_floor);
}

void DS::RenderApp()
{
	DScam.RenderCamera();
}
void DS::ReleaseApp()
{
	DScam.ReleaseCamera();
}

void DS::KeyInput(int key, int action, int mods)
{
	DScam.KeyInput(key, action, mods);
}
void DS::MouseInput(double xpos, double ypos)
{
	DScam.MouseInput(xpos, ypos);
}
