#pragma once
#pragma comment(lib,"Glfw3.lib")
#pragma comment(lib,"Glew32.lib")
#pragma comment(lib,"Glew32s.lib")

#include "TextureM.h"

class Line
{
public:
	Line();
	~Line();

	void InitBuffers(const char* vsFile, const char* fsFile, glm::vec3 start, glm::vec3 end);
	void RenderBuffers(glm::mat4 model, glm::mat4 view, glm::mat4 proj);
	void ReleaseBuffers();

public:
	GLuint mVAO, mVBO;
	Shader mShader;

	glm::vec3 TriColor;
	glm::vec3 lightPos;
	glm::vec3 lightColor;
	glm::vec3 spotDir;

};

