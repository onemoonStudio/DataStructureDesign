#pragma once
#pragma comment(lib,"Glfw3.lib")
#pragma comment(lib,"Glew32.lib")
#pragma comment(lib,"Glew32s.lib")

#include "Application.h"
#include "DSCamera.h"

class DS : public Application
{
public:
	DS(vector<pair<float, float>> move_point_pair, vector<int> floor);
	~DS();

public:
	void InitApp();
	void RenderApp();
	void ReleaseApp();

	void KeyInput(int key, int action, int mods);
	void MouseInput(double xpos, double ypos);

public:
	DSCamera DScam;
	vector<pair<float, float>> move_point__;
	vector<int> move_floor;
};
