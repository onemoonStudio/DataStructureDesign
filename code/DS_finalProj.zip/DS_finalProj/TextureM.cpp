#include "TextureM.h"


TextureM::TextureM()
{
}


TextureM::~TextureM()
{
}

void TextureM::LoadImage(GLuint *texture, const char* filename)
{

	glGenTextures(1, texture);

	FILE *fp = _fsopen(filename, "rb", _SH_DENYNO);
	if (fp == NULL)
	{
		cout << "image file not found ! " << endl;
		getchar();
	}

	stbi_set_flip_vertically_on_load(true);

	unsigned char *image = stbi_load_from_file(fp, &width, &height, &channel, 0);
	fclose(fp);

	glBindTexture(GL_TEXTURE_2D, *texture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	stbi_image_free(image);

	stbi_set_flip_vertically_on_load(false);


}


