#pragma once
#pragma comment(lib,"Glfw3.lib")
#pragma comment(lib,"Glew32.lib")
#pragma comment(lib,"Glew32s.lib")

#include <GL\glew.h>
#include <GLFW\glfw3.h>
#include <glm\glm.hpp>
#include <glm\gtc\matrix_transform.hpp>
#include <glm\gtc\type_ptr.hpp>
#include <iostream>
#include <time.h>
#include <vector>
#include <sstream>
#include "Shader.h"
#include "stb_image.h"
#include "windows.h"

#include<string>
#include<fstream>

#define STB_IMAGE_IMPLEMENTATION

using namespace std;

class TextureM
{
public:
	TextureM();
	~TextureM();

public:
	void LoadImage(GLuint *texture, const char* filename);

public:
	int width, height, channel;

};

