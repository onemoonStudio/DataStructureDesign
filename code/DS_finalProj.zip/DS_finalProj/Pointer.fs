#version 330 core

in vec3 FragPos;

out vec4 ObjColor;

void main()
{
	vec3 pointColor = vec3(1.0f, 0.0f, 0.0f);
	ObjColor = vec4(pointColor, 1.0f);
	
}