#pragma once
#pragma comment(lib,"Glfw3.lib")
#pragma comment(lib,"Glew32.lib")
#pragma comment(lib,"Glew32s.lib")

#include "TextureM.h"

class Cube
{
public:
	Cube();
	~Cube();

public:
	void InitBuffers(const char* vsFile, const char* fsFile, const char* Texture);
	void RenderBuffers(glm::mat4 model, glm::mat4 view, glm::mat4 proj);
	void ReleasBuffers();

	void computeNormal(int *indices, float *vertices);

public:
	Shader mShader;
	TextureM cube;

	GLuint mCTex;
	GLuint mVAO, mVBO, mEBO, mVBOnorm;

	float verticesNorm[18];

	glm::vec4 normal[6];

	glm::vec3 cubeColor;
	glm::vec3 lightPos;
	glm::vec3 lightColor;
	glm::vec3 spotDir;
	float cutOff;

	std::vector<glm::vec3> mNormal;

	int count;
	int PA4count;


};

