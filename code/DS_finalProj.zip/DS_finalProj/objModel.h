#pragma once
#pragma comment(lib,"Glfw3.lib")
#pragma comment(lib,"Glew32.lib")
#pragma comment(lib,"Glew32s.lib")

#include "TextureM.h"
#include "vertexBufferObject.h"
#include <string>
#include <sstream>


#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>


#include "Shader.h"

#define ESZ(elem) (int)elem.size()
#define RFOR(q,n) for(int q=n;q>=0;q--)
/********************************

Class:	CObjModel

Purpose: Class for handling obj
		 model files.

********************************/

class objModel
{
public:
	bool loadModel(std::string sFileName, const char* vsFile, const char* fsFile, const char* objfile);
	void renderModel(glm::mat4 model, glm::mat4 view, glm::mat4 proj);
	void releaseModel();

	//void computeNormal(int *indices, float *vertices);

	int getPolygonCount();

	void translate(glm::vec3 t);
	void rotation(glm::vec3 axis, float angle);
	void scale(glm::vec3 s);

	GLuint getProgram();

	objModel();
	~objModel();

public:
	bool bLoaded;
	int iAttrBitField;
	int iNumFaces;

	glm::mat4 mModel;
	Shader mShader;

	GLuint mTexture;
	TextureM mIron;

	CVertexBufferObject vboModelData;
	GLuint uiVAO;

	glm::vec3 lightPos;
	glm::vec3 lightColor;
	glm::vec3 spotDir;
	glm::vec3 camPos;
	float cutOff;

	int count;
	int PA4count;
};